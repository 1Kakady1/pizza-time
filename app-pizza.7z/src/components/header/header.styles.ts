import { StyleSheet } from 'react-native';
import { primary } from '../../consts/colors.const';

export const stylesHeader = StyleSheet.create({
    header: {
        backgroundColor: primary[500]
    }
});
