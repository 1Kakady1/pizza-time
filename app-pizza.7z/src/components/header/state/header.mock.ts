import { IHeader } from './header.model';

export const settingInit: IHeader = {
    isOpenSetting: false
};
