export interface IHeader {
    isOpenSetting: boolean;
}
