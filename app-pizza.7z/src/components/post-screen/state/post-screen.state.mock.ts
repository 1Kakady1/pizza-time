import { IPost } from './post-screen.state.model';

export const cartInit: IPost = {
    post: undefined,
    id: '',
    size: '',
    isLoad: true,
    isRefresh: false,
    error: ''
};
