export const POST_KEY = 'post';
