export interface IShareProps {
    uri: string;
    message: string;
    title: string;
}
