export const SHARE_KEY = 'share';
