import { IShare } from './share.model';

export const shareInit: IShare = {
    uri: '',
    message: '',
    title: ''
};
