export interface IShare {
    uri: string;
    message: string;
    title: string;
}

export interface ISharePayload {
    uri: string;
    message: string;
    title: string;
}
