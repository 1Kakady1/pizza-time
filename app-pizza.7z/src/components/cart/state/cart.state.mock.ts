import { ICart } from './cart.state.model';

export const cartInit: ICart = {
    products: [],
    isOpen: false
};
