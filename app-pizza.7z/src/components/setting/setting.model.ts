export interface ISetting {
    onOpen: () => void;
    onClose: () => void;
    isOpen: boolean;
}
