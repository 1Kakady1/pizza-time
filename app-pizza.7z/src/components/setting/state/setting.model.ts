export interface ISetting {
    isOpen: boolean;
}
