import { ISetting } from './setting.model';

export const settinggInit: ISetting = {
    isOpen: false
};
