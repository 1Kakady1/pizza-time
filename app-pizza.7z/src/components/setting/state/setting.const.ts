export const SETTING_KEY = 'settinggKey';
