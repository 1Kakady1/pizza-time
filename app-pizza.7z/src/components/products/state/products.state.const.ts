export const PRODUCTS_KEY = 'products';
