export interface IContanerDefault {
    children: JSX.Element | JSX.Element[];
    back?: boolean;
    title?: string;
    settings?: boolean;
}
