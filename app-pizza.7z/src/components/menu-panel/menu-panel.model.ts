export interface IMenuPanelProps {}
