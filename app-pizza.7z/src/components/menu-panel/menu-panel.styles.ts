import { StyleSheet } from 'react-native';
import { black, gray } from '../../consts/colors.const';

export const stylesMenuPanel = StyleSheet.create({
    container: {}
});
