export const CART_PANEL_KEY = 'cartPanel';
