export interface ICartPanel {
    size: string;
}
