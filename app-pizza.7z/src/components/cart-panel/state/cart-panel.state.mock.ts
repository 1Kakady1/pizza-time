import { ICartPanel } from './cart-panel.state.model';

export const cartInit: ICartPanel = {
    size: ''
};
