export interface IProductsPanelProps {
    drawerOpen: () => void;
    onOpenSearch: () => void;
    preview: string;
}
