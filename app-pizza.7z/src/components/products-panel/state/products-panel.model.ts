export interface IProductsPanel {
    isSearch: boolean;
    preview: string;
    currentCat: string;
}
