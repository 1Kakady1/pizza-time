import { IProductsPanel } from './products-panel.model';

export const productsPanelInit: IProductsPanel = {
    isSearch: false,
    preview: '',
    currentCat: 'all'
};
