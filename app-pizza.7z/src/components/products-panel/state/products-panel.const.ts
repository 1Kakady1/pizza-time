export const PRODUCTS_PANEL_KEY = 'productsPanel';
