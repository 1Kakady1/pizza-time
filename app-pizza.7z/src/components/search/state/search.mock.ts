import { ISearch } from './search.model';

export const searchInit: ISearch = {
    isOpen: false,
    query: '',
    result: [],
    isLoad: false,
    error: ''
};
