export const SEARCH_KEY = 'search';
