import { ICatData } from './cat.state.model';

export const catInit: ICatData = {
    cat: [],
    currentCat: 'all',
    isLoad: true,
    error: ''
};
