export const CAT_KEY = 'catList';
