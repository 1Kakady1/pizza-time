const firebaseConfig = {
  apiKey: "AIzaSyA-6GcEIc4k9rKa4n_OiNowc2qEQtXg46E",
  authDomain: "product-shop-b3677.firebaseapp.com",
  projectId: "product-shop-b3677",
  storageBucket: "product-shop-b3677.appspot.com",
  messagingSenderId: "529767072059",
  appId: "1:529767072059:web:1ca6e588ebcfe619c0f71e",
  measurementId: "G-TY2Z76J6T0"
};

export default firebaseConfig