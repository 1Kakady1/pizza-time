//TODO: Try to pass constants
export type screenRoute = {
    HomeScreen: undefined;
    PostItemScreen: {
        id: string;
    };
};
