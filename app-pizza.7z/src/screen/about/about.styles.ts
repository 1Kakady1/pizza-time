import { StyleSheet } from 'react-native';
export const stylesPost = StyleSheet.create({
    container: {
        position: 'relative',
        flex: 1,
        flexDirection: 'column',
        backgroundColor: '#fff'
    }
});
